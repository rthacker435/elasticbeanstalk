"""
Routes and views for the flask application.
"""
import pyodbc
import requests as r
from datetime import datetime
from flask import Flask, g, render_template, abort, request, flash
#from azure_flask import app
import json
import os
from pymongo import MongoClient
from bson.json_util import dumps, loads
from bson.objectid import ObjectId

#from os import environ
#from azure_flask import app

app = Flask(__name__)

connection_string = 'Driver={ODBC Driver 17 for SQL Server};Server=mis-finalproject.database.windows.net,1433;Database=FinalProject;Uid=rtadmin;Pwd=28_Nosler;'
conn = pyodbc.connect(connection_string, autocommit=True)
curse = conn.cursor()
app.secret_key ='password'
@app.before_request
def before_request():
    try:
        g.sql_conn =  pyodbc.connect(connection_string, autocommit=True)
    except Exception:
        abort(500, "No database connection could be established.")

@app.teardown_request
def teardown_request(exception):
    try:
        g.sql_curs.close()
    except AttributeError:
        pass
@app.route("/", methods=['GET', 'POST'])
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now()
    )

@app.route('/contact')
def contact():
    """Renders the contact page."""
    return render_template(
        'contact.html',
        title='Contact',
        year=datetime.now().year,
        message='Your contact page.'
    )

@app.route('/about')
def about():
    """Renders the about page."""
    return render_template(
        'about.html',
        title='About',
        year=datetime.now().year,
        message='Your application description page.'
    )


@app.route('/data')
def data():

    """Renders the data page."""
    curs = g.sql_conn.cursor()
    query = "SELECT Distinct(URL) FROM [dbo].[URLs]"
    curs.execute(query)

    columns = [column[0] for column in curs.description]
    data = []

    for row in curs.fetchall():
        data.append(dict(zip(columns, row)))
    raw_data = json.dumps(data, indent=4, sort_keys=True, default=str)

    return render_template(
        'data.html',
        title='Data',
        message='Get your data.',
        news_data=loads(raw_data)
    )
@app.route('/single/<string:url>')
def single(url):
    """Renders the data page."""
    curs = g.sql_conn.cursor()

    query = "Select * FROM [dbo].[URLs] Where url =?"


    print(query)
    curs.execute(query,url)

    columns = [column[0] for column in curs.description]
    data = []

    for row in curs.fetchall():
        flash(data.append(dict(zip(columns, row))))
    raw_data = json.dumps(data, indent=4, sort_keys=True, default=str)


    return render_template(
        'single.html',
        title='Single',
        message='Get data.',
        news_data=loads(raw_data)
    )


if __name__=="__main__":
    app.run(host='0.0.0.0')